

stickleback<-read.csv("Journal_figs/single_locus_selection/stickleback_fitness/Stickleback_fitness.csv")

stickleback[4,c("CC","LC","LL")]
stickleback[10,c("CC","LC","LL")]


stickleback[10,c("CC","LC","LL")]/stickleback[4,c("CC","LC","LL")]/2.28