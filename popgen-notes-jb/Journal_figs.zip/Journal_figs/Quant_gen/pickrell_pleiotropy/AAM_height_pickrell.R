


 AAM_Height<-read.csv("~/Dropbox/Courses/Popgen_teaching_Notes/Journal_figs/Quant_gen/pickrell_pleiotropy/AAM_height_pickrell.csv")
 plot(AAM_Height,pch=19,xlab="AAM effect size",ylab="Height effect size",cex.axis=1.2,cex.lab=1.4,cex=1.5)
 
 
 dev.copy2pdf(file="Journal_figs/Quant_gen/pickrell_pleiotropy/AAM_height.pdf")
 
